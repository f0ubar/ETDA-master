﻿using System;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;

namespace Dreamer.Mapping
{
    public class PathFinderNode : MapObject
    {
        public PathFinderNode(MapTile MapTile) : base(MapTile.Map, MapTile.Point)
        {
            this.MapTile = MapTile;
            Blocked = MapTile.IsWall;
            IsDrawable = true;
        }
        public MapTile MapTile { get; set; }
        public PathFinderNode PreviousNode { get; set; }
        public PathFinderNode NextNode { get; set; }
        public bool Opened { get; set; } = false;
        public bool Closed { get; set; } = false;
        public bool Blocked { get; set; } = false;
        public PathFinderNode[] AdjacentNodes { get; set; }
        public Direction Direction { get { return NextNode == null ? Direction.None : MapTile.Point.DirectDirectionTowards(NextNode.Point); } }

        public PathFinderNode BackConnectToFirstNode()
        {
            PathFinderNode node = this;
            while (node.PreviousNode != null) node = (node.PreviousNode.NextNode = node).PreviousNode;
            return node;
        }
        public PathFinderNode FirstNode
        {
            get
            {
                PathFinderNode node = this;
                while (node.PreviousNode != null) node = node.PreviousNode;
                return node;
            }
        }
        public PathFinderNode LastNode
        {
            get
            {
                PathFinderNode node = this;
                while (node.NextNode != null) node = node.NextNode;
                return node;
            }
        }
        public PathFinderNode FirstNodeWhere(Func<PathFinderNode, bool> func)
        {
            PathFinderNode node = this;
            while (node != null)
            {
                if (func(node))
                    return node;
                node = node.NextNode;
            }
            return null;
        }
        public PathFinderNode FirstAtPoint(Point Point)
        {
            return FirstNodeWhere(o => Point == o.Point);
        }
        public PathFinderNode FirstNodeBackwardsWhere(Func<PathFinderNode, bool> func)
        {
            PathFinderNode node = this;
            while (node != null)
            {
                if (func(node))
                    return node;
                node = node.PreviousNode;
            }
            return null;
        }
        static readonly Brush
            ScreenBrush = new SolidBrush(Color.FromArgb(158, 195, 255)),
            SightBrush = new SolidBrush(Color.FromArgb(102, 161, 255)),
            PickupBrush = new SolidBrush(Color.FromArgb(60, 100, 255)),
            PointBrush = new SolidBrush(Color.FromArgb(0, 0, 255));
        public override void OnDraw(Graphics Graphics, Point Aspect, int LayerHeight)
        {
            switch (LayerHeight)
            {
                case 25:
                    {
                        Point[] points = Point + (new Point(8, 8) * Point.AllDirections);
                        points[2] += Point.East;
                        points[3] += Point.South;
                        points.Function((i, p) => p * Aspect);
                        Graphics.FillPolygon(ScreenBrush, points.Select(point => point.ToPoint()).ToArray());
                    }
                    break;
                case 50:
                    {
                        Rectangle rectangle = ((Point - new Point(4, 4)) * Aspect).ToRectangle(Aspect * new Point(9, 9));
                        Graphics.FillRectangle(SightBrush, rectangle);
                    }
                    break;
                case 75:
                    {
                        Rectangle rectangle = ((Point - new Point(2, 2)) * Aspect).ToRectangle(Aspect * new Point(5, 5));
                        Graphics.FillRectangle(PickupBrush, rectangle);
                    }
                    break;
                case 125:
                    {
                        Rectangle rectangle = (Point * Aspect).ToRectangle(Aspect);
                        Graphics.FillRectangle(PointBrush, rectangle);
                    }
                    break;
            }
        }
        private class NodeEnumerator : IEnumerator
        {
            public NodeEnumerator(PathFinderNode CurrentNode)
            {
                FirstNode = this.CurrentNode = CurrentNode;
            }
            private PathFinderNode FirstNode { get; set; }
            private PathFinderNode CurrentNode { get; set; }
            public object Current { get { return CurrentNode; } }
            public bool MoveNext()
            {
                CurrentNode = CurrentNode.NextNode;
                return CurrentNode != null;
            }
            public void Reset() { CurrentNode = FirstNode; }
        }
        public IEnumerator GetEnumerator()
        {
            return new NodeEnumerator(this);
        }
    }
}
